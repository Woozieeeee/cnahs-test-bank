"use client";

import MotionButton from "@/components/motion/motionButton";

import BackButton from "@/components/common/backButton";

interface Props {
  onCreate: () => void;
}

export default function SectionsHeader({
  onCreate,
}: Props) {
  return (
    <div
      className="
        flex
        items-center
        justify-between
      "
    >
      <div className="space-y-4">
        <BackButton
          href="/admin/academic"
          label="Back to Academic Management"
        />

        <div>
          <h1
            className="
              text-3xl
              font-bold
              text-foreground
            "
          >
            Sections
          </h1>

          <p className="mt-2 text-muted-foreground">
            Manage academic sections and classrooms.
          </p>
        </div>
      </div>

      <MotionButton
        onClick={onCreate}
        className="
          rounded-xl
          bg-card
          px-4
          py-2
          font-medium
          text-foreground
          transition
          hover:bg-muted
        "
      >
        Create Section
      </MotionButton>
    </div>
  );
}
