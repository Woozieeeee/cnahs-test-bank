"use client";

import { useEffect, useState } from "react";

import MotionModal from "@/components/motion/motionModal";

import MotionButton from "@/components/motion/motionButton";

import { updateSection } from "@/services/academic_service";

import { successToast, errorToast } from "@/lib/swal";

import type { Section } from "@/types/section";

interface Props {
  open: boolean;

  onOpenChange: (open: boolean) => void;

  section: Section | null;

  onSuccess: () => void;
}

export default function EditSectionModal({
  open,
  onOpenChange,
  section,
  onSuccess,
}: Props) {
  const [program, setProgram] = useState("BSN");

  const [yearLevel, setYearLevel] = useState(1);

  const [sectionCode, setSectionCode] = useState("");

  const [loading, setLoading] = useState(false);

  // =========================
  // PREFILL
  // =========================

  useEffect(() => {
    if (!section) return;

    setProgram(section.program);

    setYearLevel(section.yearLevel);

    setSectionCode(section.sectionCode);
  }, [section]);

  // =========================
  // GENERATED NAME
  // =========================

  const generatedName = `${program}-${yearLevel}${sectionCode}`;

  // =========================
  // SUBMIT
  // =========================

  const handleSave = async () => {
    if (!section) return;

    try {
      setLoading(true);

      await updateSection(section.id, {
        program,

        yearLevel,

        sectionCode,
      });

      successToast("Section updated successfully.");

      onSuccess();

      onOpenChange(false);
    } catch (error: any) {
      errorToast(
        error.response?.data?.message ||
          "Failed to update section."
      );
    } finally {
      setLoading(false);
    }
  };

  if (!open || !section) return null;

  return (
    <MotionModal open={open}>
      <div className="p-6">
        {/* HEADER */}

        <div>
          <h2
            className="
              text-2xl
              font-bold
              text-foreground
            "
          >
            Edit Section
          </h2>

          <p
            className="
              mt-1
              text-sm
              text-muted-foreground
            "
          >
            Update section details.
          </p>
        </div>

        {/* FORM */}

        <div className="mt-6 space-y-4">
          {/* PROGRAM */}

          <div>
            <label
              className="
                mb-2
                block
                text-sm
                font-medium
                text-foreground
              "
            >
              Program
            </label>

            <select
              value={program}
              onChange={(e) => setProgram(e.target.value)}
              className="
                w-full
                rounded-xl
                border
                border-input
                bg-background
                px-4
                py-3
                text-foreground
                outline-none
                transition
                focus:border-ring
              "
            >
              <option value="BSN">BSN</option>
            </select>
          </div>

          {/* YEAR LEVEL */}

          <div>
            <label
              className="
                mb-2
                block
                text-sm
                font-medium
                text-foreground
              "
            >
              Year Level
            </label>

            <select
              value={yearLevel}
              onChange={(e) =>
                setYearLevel(Number(e.target.value))
              }
              className="
                w-full
                rounded-xl
                border
                border-input
                bg-background
                px-4
                py-3
                text-foreground
                outline-none
                transition
                focus:border-ring
              "
            >
              {[1, 2, 3, 4].map((year) => (
                <option key={year} value={year}>
                  Year {year}
                </option>
              ))}
            </select>
          </div>

          {/* SECTION CODE */}

          <div>
            <label
              className="
                mb-2
                block
                text-sm
                font-medium
                text-foreground
              "
            >
              Section Code
            </label>

            <input
              type="text"
              value={sectionCode}
              onChange={(e) =>
                setSectionCode(e.target.value.toUpperCase())
              }
              maxLength={2}
              className="
                w-full
                rounded-xl
                border
                border-input
                bg-background
                px-4
                py-3
                text-foreground
                outline-none
                transition
                focus:border-ring
              "
            />
          </div>

          {/* GENERATED NAME */}

          <div
            className="
              rounded-xl
              bg-muted
              p-4
            "
          >
            <p
              className="
                text-xs
                font-medium
                uppercase
                tracking-wide
                text-muted-foreground
              "
            >
              Generated Section Name
            </p>

            <p
              className="
                mt-2
                text-lg
                font-semibold
                text-foreground
              "
            >
              {generatedName}
            </p>
          </div>
        </div>

        {/* ACTIONS */}

        <div
          className="
            mt-6
            flex
            justify-end
            gap-3
          "
        >
          <MotionButton
            onClick={() => onOpenChange(false)}
            className="
              rounded-xl
              border
              border-border
              bg-card
              px-4
              py-2
              text-sm
              font-medium
              text-muted-foreground
            "
          >
            Cancel
          </MotionButton>

          <MotionButton
            onClick={handleSave}
            disabled={loading}
            className="
              rounded-xl
              bg-primary
              px-4
              py-2
              text-sm
              font-medium
              text-primary-foreground
              transition
              hover:bg-primary/90
            "
          >
            {loading ? "Saving..." : "Save Changes"}
          </MotionButton>
        </div>
      </div>
    </MotionModal>
  );
}
