import MotionCard from "@/components/motion/motionCard";

import StudentSessionTimelineDot from "./studentSessionTimelineDot";

import StudentSessionTimelineCategories from "./studentSessionTimelineCategories";

interface Props {
  event: any;

  isLast?: boolean;
}

export default function StudentSessionTimelineItem({
  event,
  isLast = false,
}: Props) {
  const severityColor =
    event.severity === "ERROR"
      ? "bg-red-500"
      : event.severity === "WARNING"
        ? "bg-yellow-500"
        : "bg-green-500";

  return (
    <div className="grid grid-cols-[84px_28px_1fr] gap-4">
      {/* TIME */}

      <div
        className="
          pt-5
          text-right
          text-sm
          text-muted-foreground
        "
      >
        {new Date(event.createdAt).toLocaleTimeString()}
      </div>

      {/* DOT */}

      <StudentSessionTimelineDot
        severityColor={severityColor}
        isLast={isLast}
      />

      {/* CARD */}

      <MotionCard>
        <div
          className="
            rounded-xl
            border
            bg-muted/30
            p-5
          "
        >
          <h4
            className="
              font-semibold
              text-foreground
            "
          >
            {event.title}
          </h4>

          <p
            className="
              mt-3
              text-sm
              text-muted-foreground
            "
          >
            {event.description}
          </p>

          <StudentSessionTimelineCategories
            categories={event.categories}
          />

          <div
            className="
              mt-3
              text-xs
              text-muted-foreground
            "
          >
            {new Date(event.createdAt).toLocaleString()}
          </div>
        </div>
      </MotionCard>
    </div>
  );
}
