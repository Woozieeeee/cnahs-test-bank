import { memo } from "react";

interface Props {
  children: React.ReactNode;
}

function TimelineTime({ children }: Props) {
  return (
    <div
      className="
        text-right
        text-xs
        text-muted-foreground
      "
    >
      {children}
    </div>
  );
}

export default memo(TimelineTime);
