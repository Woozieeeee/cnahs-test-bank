interface Props {
  children: React.ReactNode;
}

export default function FormLabel({ children }: Props) {
  return (
    <label
      className="
        text-sm
        font-medium
        text-muted-foreground
      "
    >
      {children}
    </label>
  );
}
