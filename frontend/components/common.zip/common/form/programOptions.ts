import { PROGRAMS } from "@/constant/academic";

export const PROGRAM_OPTIONS = PROGRAMS.map((program) => ({
  label: program,
  value: program,
}));
