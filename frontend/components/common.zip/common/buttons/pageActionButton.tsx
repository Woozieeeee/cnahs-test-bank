import { memo } from "react";

import MotionButton from "@/components/motion/motionButton";

interface Props {
  children: React.ReactNode;

  onClick: () => void;
}

function PageActionButton({ children, onClick }: Props) {
  return (
    <MotionButton
      onClick={onClick}
      className="
        rounded-xl
        bg-card
        px-4
        py-2
        font-medium
        text-foreground

        transition-all
        duration-200

        hover:bg-muted
      "
    >
      {children}
    </MotionButton>
  );
}

export default memo(PageActionButton);
