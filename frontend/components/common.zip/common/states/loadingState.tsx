"use client";

import { memo } from "react";

interface Props {
  title?: string;

  description?: string;
}

function LoadingState({
  title = "Loading...",
  description,
}: Props) {
  return (
    <div
      className="
        rounded-2xl
        border
        border-border
        bg-card
        p-10
        text-center
      "
    >
      <div
        className="
          mx-auto
          h-8
          w-8
          animate-spin
          rounded-full
          border-2
          border-muted
          border-t-primary
        "
      />

      <h2
        className="
          mt-4
          text-lg
          font-semibold
          text-foreground
        "
      >
        {title}
      </h2>

      {description && (
        <p
          className="
            mt-2
            text-muted-foreground
          "
        >
          {description}
        </p>
      )}
    </div>
  );
}

export default memo(LoadingState);
