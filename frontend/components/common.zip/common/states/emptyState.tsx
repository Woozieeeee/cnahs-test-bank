"use client";

import { memo } from "react";

interface Props {
  title: string;

  description?: string;
}

function EmptyState({ title, description }: Props) {
  return (
    <div
      className="
        rounded-2xl
        border
        border-dashed
        border-border
        bg-card
        p-10
        text-center
      "
    >
      <h2
        className="
          text-lg
          font-semibold
          text-foreground
        "
      >
        {title}
      </h2>

      {description && (
        <p
          className="
            mt-2
            text-muted-foreground
          "
        >
          {description}
        </p>
      )}
    </div>
  );
}

export default memo(EmptyState);
