"use client";

import { memo } from "react";

import MotionButton from "@/components/motion/motionButton";

interface Props {
  title?: string;

  description?: string;

  onRetry?: () => void;
}

function ErrorState({
  title = "Something went wrong.",
  description,
  onRetry,
}: Props) {
  return (
    <div
      className="
        rounded-2xl
        border
        border-red-200
        bg-card
        p-10
        text-center
      "
    >
      <h2
        className="
          text-lg
          font-semibold
          text-red-600
        "
      >
        {title}
      </h2>

      {description && (
        <p
          className="
            mt-2
            text-muted-foreground
          "
        >
          {description}
        </p>
      )}

      {onRetry && (
        <MotionButton
          onClick={onRetry}
          className="
            mt-5
            rounded-xl
            bg-primary
            px-4
            py-2
            text-primary-foreground
          "
        >
          Retry
        </MotionButton>
      )}
    </div>
  );
}

export default memo(ErrorState);
