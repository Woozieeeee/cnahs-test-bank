"use client";

import { memo } from "react";

interface Props {
  title?: string;

  description?: string;
}

function NotFoundState({
  title = "Not Found",
  description = "The requested resource could not be found.",
}: Props) {
  return (
    <div
      className="
        rounded-2xl
        border
        border-dashed
        border-border
        bg-card
        p-10
        text-center
      "
    >
      <h2
        className="
          text-xl
          font-semibold
          text-foreground
        "
      >
        {title}
      </h2>

      <p
        className="
          mt-2
          text-muted-foreground
        "
      >
        {description}
      </p>
    </div>
  );
}

export default memo(NotFoundState);
