import { memo } from "react";

interface Props {
  children: React.ReactNode;
}

function CategoryBadge({ children }: Props) {
  return (
    <span
      className="
        rounded-md
        bg-muted
        px-2
        py-1
        text-[11px]
        font-medium
        text-muted-foreground
      "
    >
      {children}
    </span>
  );
}

export default memo(CategoryBadge);
