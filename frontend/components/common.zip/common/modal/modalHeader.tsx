interface Props {
  title: string;

  description?: string;

  onClose: () => void;
}

export default function ModalHeader({
  title,
  description,
  onClose,
}: Props) {
  return (
    <div
      className="
        flex
        items-start
        justify-between
      "
    >
      <div>
        <h2
          className="
            text-2xl
            font-bold
            text-foreground
          "
        >
          {title}
        </h2>

        {description && (
          <p
            className="
              mt-1
              text-sm
              text-muted-foreground
            "
          >
            {description}
          </p>
        )}
      </div>

      <button
        onClick={onClose}
        className="
          rounded-lg
          px-3
          py-1
          text-muted-foreground

          transition-all
          duration-200

          hover:bg-muted
        "
      >
        ✕
      </button>
    </div>
  );
}
