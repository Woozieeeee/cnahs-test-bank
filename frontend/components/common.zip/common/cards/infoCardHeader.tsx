import { memo } from "react";

interface Props {
  label: string;
}

function InfoCardHeader({ label }: Props) {
  return (
    <p
      className="
        text-xs
        uppercase
        tracking-wide
        text-muted-foreground
      "
    >
      {label}
    </p>
  );
}

export default memo(InfoCardHeader);
