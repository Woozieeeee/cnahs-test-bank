import { memo } from "react";

import InfoCard from "./infoCard";

interface Props {
  title: string;

  description: string;
}

function InfoCardSection({ title, description }: Props) {
  return (
    <InfoCard>
      <h3
        className="
          text-sm
          font-semibold
          text-foreground
        "
      >
        {title}
      </h3>

      <p
        className="
          mt-3
          text-sm
          leading-7
          text-muted-foreground
        "
      >
        {description}
      </p>
    </InfoCard>
  );
}

export default memo(InfoCardSection);
