import { memo } from "react";

interface Props {
  children: React.ReactNode;

  className?: string;
}

function InfoCard({ children, className = "" }: Props) {
  return (
    <div
      className={`
        rounded-xl
        border
        border-border
        bg-muted/20
        p-4

        ${className}
      `}
    >
      {children}
    </div>
  );
}

export default memo(InfoCard);
