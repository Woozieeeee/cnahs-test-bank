import { memo } from "react";

interface Props {
  label: string;
}

function CardFooterLink({ label }: Props) {
  return (
    <div
      className="
        mt-6
        flex
        items-center
        justify-between
        border-t
        border-border
        pt-4
      "
    >
      <p
        className="
          text-sm
          text-muted-foreground
        "
      >
        {label}
      </p>

      <span
        className="
          text-sm
          font-medium
          text-foreground
        "
      >
        →
      </span>
    </div>
  );
}

export default memo(CardFooterLink);
