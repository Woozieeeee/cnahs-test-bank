"use client";

import MotionCard from "@/components/motion/motionCard";

import { Subject } from "@/types/subject";

import SubjectCardHeader from "./card/subjectCardHeader";

import SubjectCardFaculty from "./card/subjectCardFaculty";

import SubjectCardSections from "./card/subjectCardSections";

interface Props {
  subject: Subject;

  onEdit: () => void;

  onAssignFaculty: () => void;

  onAssignSections: () => void;
}

export default function SubjectCard({
  subject,

  onEdit,

  onAssignFaculty,

  onAssignSections,
}: Props) {
  const sectionSubjects = subject.sectionSubjects || [];

  return (
    <MotionCard>
      <div
        className="
          rounded-2xl
          border
          border-border
          bg-card
          p-6
          transition
          hover:border-ring
          hover:shadow-sm
        "
      >
        <SubjectCardHeader
          subject={subject}
          sectionSubjects={sectionSubjects}
          onEdit={onEdit}
          onAssignFaculty={onAssignFaculty}
          onAssignSections={onAssignSections}
        />

        {/* DESCRIPTION */}

        <p
          className="
            mt-4
            text-sm
            leading-relaxed
            text-muted-foreground
          "
        >
          {subject.description ||
            "No description provided."}
        </p>

        <SubjectCardFaculty
          facultyName={subject.faculty?.name}
        />

        <SubjectCardSections
          sectionSubjects={sectionSubjects}
        />
      </div>
    </MotionCard>
  );
}
