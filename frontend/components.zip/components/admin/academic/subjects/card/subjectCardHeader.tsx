import { Subject, SectionSubject } from "@/types/subject";

import SubjectCardActions from "../subjectCardActions";

interface Props {
  subject: Subject;

  sectionSubjects: SectionSubject[];

  onEdit: () => void;

  onAssignFaculty: () => void;

  onAssignSections: () => void;
}

export default function SubjectCardHeader({
  subject,

  sectionSubjects,

  onEdit,

  onAssignFaculty,

  onAssignSections,
}: Props) {
  return (
    <div className="flex items-start justify-between">
      <div>
        <h2
          className="
            text-xl
            font-semibold
            text-foreground
          "
        >
          {subject.name}
        </h2>

        <p
          className="
            mt-1
            text-sm
            text-muted-foreground
          "
        >
          {subject.code}
        </p>
      </div>

      <SubjectCardActions
        hasFacultyAssigned={!!subject.faculty}
        hasSectionsAssigned={sectionSubjects.length > 0}
        onEdit={onEdit}
        onAssignFaculty={onAssignFaculty}
        onUnassignFaculty={() => {
          console.log("Unassign faculty");
        }}
        onAssignSections={onAssignSections}
        onUnassignSections={() => {
          console.log("Unassign sections");
        }}
        onArchive={() => {
          console.log("Archive subject");
        }}
      />
    </div>
  );
}
